package main;

import clientServer.IndexCalculus;

public class IndexCalculusMain {
    public static void main(String[] args) {
        IndexCalculus calculus = new IndexCalculus();
    }
}
