package main;

import clientServer.SmallStepBigStep;

public class SmallStepBigMain {
    public static void main(String[] args) {
        SmallStepBigStep checker = new SmallStepBigStep();
    }
}
