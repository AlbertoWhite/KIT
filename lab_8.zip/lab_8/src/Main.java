import clientServer.Server;
import kripthography.KriptoAlgorithms;

import java.util.ArrayList;

public class Main {
    private static KriptoAlgorithms kriptoAlgorithms = new KriptoAlgorithms();
    public static void main(String[] args)
    {
        Server server = new Server();
    }
}
