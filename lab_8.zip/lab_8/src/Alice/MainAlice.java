package Alice;

public class MainAlice {
    public static void main(String[] args)
    {

        try {
            Alice alice = new Alice("Alice"); // P, Q, d
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
