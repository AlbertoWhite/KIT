import clientServer.Server;
import cryptography.CryptoAlgorithms;

public class Main {
    public static void main(String[] args)
    {
        Server server = new Server();
    }
}
