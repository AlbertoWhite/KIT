package Alice;

public class MainAlice {
    public static void main(String[] args)
    {
            Alice alice = new Alice("Alice");
    }
}
