package Alice;

public class MainBob {
    public static void main(String[] args)
    {
        Alice alice = new Alice("Bob");
    }
}