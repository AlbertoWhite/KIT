package Alice;
import clientServer.ClientWindow;

public class Alice extends ClientWindow{
    Alice(String name) {
        super(name);
    }
}
