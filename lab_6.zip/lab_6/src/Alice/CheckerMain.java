package Alice;

import clientServer.ClientChecker;

public class CheckerMain {
    public static void main(String[] args) {
       ClientChecker checker = new ClientChecker();
    }
}
