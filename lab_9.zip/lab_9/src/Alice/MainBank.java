package Alice;

import clientServer.Bank;

public class MainBank {
    public static void main(String[] args)
    {
        //Long p = Long.parseLong(args[0]);
        //Long q = Long.parseLong(args[1]);
        Bank bank;
        /*if(args.length < 2)
            bank = new Bank(131l, 227l); // P, Q
        else
        {
            Long p = Long.parseLong(args[0]);
            Long q = Long.parseLong(args[1]);
            bank = new Bank(p, q);
        }*/
    }
}