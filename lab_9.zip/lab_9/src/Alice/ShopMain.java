package Alice;

import clientServer.Shop;

public class ShopMain {
    public static void main(String[] args) {
       Shop checker = new Shop();
    }
}
